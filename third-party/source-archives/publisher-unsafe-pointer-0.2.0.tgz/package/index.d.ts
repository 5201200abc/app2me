/**
 * Returns a pointer to the first byte of the given `ArrayBuffer` or `ArrayBufferView` as a number.
 * 
 * [See Bun's explanation on `number` vs `bigint` pointers](https://bun.com/docs/runtime/ffi#pointers)
 * 
 * ```
 * type MyPointerType = number & { __ptr: true }
 * const ptr: MyPointerType = unsafePointerOf(buffer)
 * ```
 * 
 * @unsafe The JavaScript runtime may move or deallocate objects at will, leading to invalid pointer access. Invalid pointer access can lead to attackers controlling your users' computers.
 * @see {@link unsafeBigIntPointerOf} for bigint pointers
 */
export function unsafePointerOf<T extends number>(buf: ArrayBufferLike | ArrayBufferView<ArrayBufferLike>): T

/**
 * Returns a pointer to the first byte of the given `ArrayBuffer` or `ArrayBufferView` as a bigint.
 * Bigints are slower than numbers but theoretically a safer way to represent pointers.
 * 
 * [See Bun's explanation on `number` vs `bigint` pointers](https://bun.com/docs/runtime/ffi#pointers)
 * 
 * ```
 * type MyPointerType = bigint & { __ptr: true }
 * const ptr: MyPointerType = unsafeBigIntPointerOf(buffer)
 * ```
 * 
 * @unsafe The JavaScript runtime may move or deallocate objects at will, leading to invalid pointer access. Invalid pointer access can lead to attackers controlling your users' computers.
 * @see {@link unsafePointerOf} for number pointers
 */
export function unsafeBigIntPointerOf<T extends bigint>(buf: ArrayBufferLike | ArrayBufferView<ArrayBufferLike>): T

/**
 * Unsafely create an `ArrayBuffer` aliasing the memory at `pointer + offset` with the given length.
 * 
 * ```
 * type Point3DPointer = number & { __ptr: true, __type: "Point3D" }
 * type Point3D = Float32Array & { length: 3, __type: "Point3D" }
 * 
 * function UnsafePoint32(ptr: Point3DPointer): Point3D {
 *   return new Float32Array(unsafeArrayBufferAt(ptr, 0, 3 * Float32Array.BYTES_PER_ELEMENT))
 * }
 * ```
 * 
 * @unsafe Accessing arbitrary memory can lead to attackers controlling your users' computers.
 */
export function unsafeArrayBufferAt<T extends number | bigint>(ptr: T, offset: number | undefined, byteLength: number): ArrayBuffer

/**
 * Iterates from `ptr` until the first null byte is found, or `maxBytes` bytes are reached.
 * Returns the number of bytes iterated, or `-1` if no null byte found before `maxBytes`.
 * 
 * Pass `-1` for `maxBytes` to count all bytes (which like `strlen` is unsafe).
 * 
 * ```
 * function unsafeStringAt(ptr: number) {
 *   const length = unsafeCountNonNullBytes(ptr, -1)
 *   return new TextDecoder().decode(new Uint8Array(unsafeArrayBufferAt(ptr, 0, length)))
 * }
 * 
 * const cstring = new TextEncoder().encode("Hello, world!\0")
 * const pointer = unsafePointerOf(cstring)
 * console.log(unsafeStringAt(pointer)) // "Hello, world!"
 * ```
 */
export function unsafeCountNonNullBytes<T extends number | bigint>(ptr: T, maxBytes: number): number
