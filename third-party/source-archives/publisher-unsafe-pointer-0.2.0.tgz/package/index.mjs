// Generated from index.d.ts by scripts/codegen-index-mjs.mts. Do not edit.
import { createRequire } from 'node:module'

const require = createRequire(import.meta.url)
const binding = require('./index.js')

export const unsafePointerOf = binding.unsafePointerOf
export const unsafeBigIntPointerOf = binding.unsafeBigIntPointerOf
export const unsafeArrayBufferAt = binding.unsafeArrayBufferAt
export const unsafeCountNonNullBytes = binding.unsafeCountNonNullBytes
