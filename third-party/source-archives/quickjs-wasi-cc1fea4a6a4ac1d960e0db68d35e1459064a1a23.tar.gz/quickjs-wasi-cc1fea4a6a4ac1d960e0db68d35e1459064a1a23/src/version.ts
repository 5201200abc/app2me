// Auto-synced with package.json version. Do not edit manually.
export const VERSION = "2.2.0";
