/*
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/
 */
mod config;
mod extensions;
mod util;

use anyhow::Result;
use proc_macro2::TokenStream;
use quote::quote;
use syn::Ident;
use ubrn_common::CrateMetadata;
use uniffi_bindgen::{
    interface::{FfiArgument, FfiCallbackFunction, FfiFunction, FfiType},
    ComponentInterface,
};
use util::{ident, if_or_default, if_then_map, map_or_default, snake_case_ident};

use crate::{
    bindings::{extensions::FfiCallbackFunctionExt as _, metadata::ModuleMetadata},
    switches::SwitchArgs,
    AbiFlavor,
};
pub(crate) use config::RustConfig as Config;
use extensions::{
    ComponentInterfaceExt as _, FfiCallbackFunction2, FfiDefinition2, FfiStruct2,
    RustFfiCallbackFunctionExt as _,
};

#[allow(unused_variables)]
pub(crate) fn generate_rs(
    ci: &ComponentInterface,
    module: &ModuleMetadata,
    config: &Config,
    switches: &SwitchArgs,
    try_format_code: bool,
) -> Result<String> {
    let mut template = ComponentTemplate::new(config, switches);
    let output: TokenStream = template.ci(ci);
    let code = formatted(output, try_format_code)?;
    Ok(code)
}

pub(crate) fn generate_entrypoint(
    crate_: &CrateMetadata,
    modules: &[ModuleMetadata],
) -> Result<String> {
    let prelude = entrypoint_prelude(crate_);
    let mods: TokenStream = modules
        .iter()
        .map(|m| {
            let namespace = ident(&m.rs_module());
            quote! { mod #namespace; }
        })
        .collect();
    let src = quote! {
        #prelude

        #mods
    };
    formatted(src, true)
}

fn entrypoint_prelude(crate_: &CrateMetadata) -> TokenStream {
    let crate_ident = ident(crate_.library_name());
    // We import the target crate here.
    // Allowing `unused_imports` because rustc doesn't use the import,
    // even though the linker does.
    quote! {
        #[allow(unused_imports)]
        use #crate_ident;
    }
}

fn formatted(tokens: TokenStream, try_format_code: bool) -> Result<String> {
    let code = if try_format_code {
        let syntax_tree = syn::parse2(tokens)?;
        prettyplease::unparse(&syntax_tree)
    } else {
        TokenStream::to_string(&tokens)
    };
    Ok(code)
}

struct FlavorParams<'a> {
    runtime_module: &'a str,
}

impl FlavorParams<'_> {
    fn runtime_module(&self) -> Ident {
        ident(self.runtime_module)
    }

    fn foreign_ident(&self, suffix: &str) -> Ident {
        ident(&format!("ubrn_{suffix}"))
    }
}

// wasm-bindgen >=0.2.114 collapses #[wasm_bindgen]-exposed structs that
// share an identical Rust ident into one JS class breaking foreign-future callbacks.
// Suffix the ident with the containing module's name so each is a distinct Rust type.
// See https://github.com/wasm-bindgen/wasm-bindgen/pull/4977
fn callback_fn_ident(module: &Ident) -> Ident {
    use heck::ToUpperCamelCase;
    ident(&format!(
        "JsCallbackFn{}",
        module.to_string().to_upper_camel_case()
    ))
}

fn wasm_flavor() -> FlavorParams<'static> {
    FlavorParams {
        runtime_module: "uniffi_runtime_javascript",
    }
}

impl From<&AbiFlavor> for FlavorParams<'_> {
    fn from(value: &AbiFlavor) -> Self {
        match value {
            AbiFlavor::Jsi => unreachable!("Jsi should be only generating C++ not Rust"),
            AbiFlavor::Napi => unreachable!("Napi should be only generating TypeScript not Rust"),
            AbiFlavor::Wasm => wasm_flavor(),
        }
    }
}

#[allow(dead_code)]
struct GeneratorParams<'params> {
    config: &'params Config,
    switches: &'params SwitchArgs,
}

impl<'params> GeneratorParams<'params> {
    fn new(config: &'params Config, switches: &'params SwitchArgs) -> Self {
        Self { config, switches }
    }
}

#[derive(Debug, Default)]
struct GeneratorState;

#[allow(dead_code)]
struct ComponentTemplate<'a> {
    state: GeneratorState,
    params: GeneratorParams<'a>,
    flavor: FlavorParams<'a>,
}

impl<'a> ComponentTemplate<'a> {
    fn new(config: &'a Config, switches: &'a SwitchArgs) -> Self {
        let params = GeneratorParams::new(config, switches);
        let state = GeneratorState;
        let flavor = FlavorParams::from(&switches.flavor);
        Self {
            params,
            state,
            flavor,
        }
    }

    fn ci(&mut self, ci: &ComponentInterface) -> TokenStream {
        let prelude = self.prelude(ci);

        let definitions = ci
            .ffi_definitions2()
            .map(|f| self.ffi_definition(&f))
            .collect::<TokenStream>();

        let ffi_funcs = ci
            .iter_ffi_functions_js_to_abi_rust()
            .map(|f| self.ffi_function(&f))
            .collect::<TokenStream>();

        let extern_c: TokenStream = ci
            .iter_ffi_functions_js_to_abi_rust()
            .map(|f| self.ffi_function_decl_c_abi(&f))
            .collect();

        quote! {
            // Generated by uniffi-bindgen-react-native
            #prelude

            extern "C" {
                #extern_c
            }

            #ffi_funcs

            #definitions
        }
    }

    fn runtime_ident(&self) -> Ident {
        ident("js")
    }

    fn uniffi_ident(&self) -> Ident {
        ident("u")
    }

    fn prelude(&self, _ci: &ComponentInterface) -> TokenStream {
        let runtime_module_ident = self.flavor.runtime_module();
        let runtime_ident = self.runtime_ident();
        let uniffi_ident = self.uniffi_ident();
        quote! {
            #[allow(unused_imports)]
            use #runtime_module_ident::{self as #runtime_ident, uniffi as #uniffi_ident, IntoJs, IntoRust};

            use wasm_bindgen::prelude::wasm_bindgen;
        }
    }

    fn ffi_definition(&mut self, definition: &FfiDefinition2) -> TokenStream {
        match definition {
            FfiDefinition2::CallbackFunction(cb) => self.ffi_callback(cb),
            FfiDefinition2::FunctionLiteral(cb) => self.ffi_function_literal(cb),
            FfiDefinition2::Struct(s) => self.ffi_struct(s),
        }
    }

    fn ffi_function_decl_c_abi(&mut self, func: &FfiFunction) -> TokenStream {
        let uniffi = self.uniffi_ident();
        let func_ident = ident(func.name());

        let args_decl = self.arg_list_decl(&func.arguments(), |t| self.ffi_type_rust(t));

        let decl_suffix = map_or_default(func.return_type(), |type_| {
            let return_type = self.ffi_type_rust(type_);
            quote! { -> #return_type }
        });

        let call_status = if_then_map(func.has_rust_call_status_arg(), || {
            let rust_status_ident = ident("status_");
            quote! { #rust_status_ident: &mut #uniffi::RustCallStatus }
        });

        quote! {
            fn #func_ident(#args_decl #call_status) #decl_suffix;
        }
    }

    fn ffi_function(&mut self, func: &FfiFunction) -> TokenStream {
        let runtime = self.runtime_ident();
        let uniffi = self.uniffi_ident();

        let annotation = quote! { #[wasm_bindgen] };
        let func_ident = ident(func.name());
        let foreign_func_ident = self.flavor.foreign_ident(func.name());

        let args = func.arguments();
        let js_args_decl = self.arg_list_decl(&args, |t| self.ffi_type_foreign_to_rust(t));

        let args_into_rust: TokenStream =
            self.arg_list_convert(&args, |ident, type_| self.convert_to_rust(ident, type_));

        let has_return = func.return_type().is_some();

        let decl_suffix = if let Some(type_) = func.return_type() {
            let return_type = self.ffi_type_foreign(type_);
            quote! { -> #return_type }
        } else {
            quote! {}
        };

        let call_suffix = if_or_default(has_return, quote! { .into_js() });

        let needs_call_status = func.has_rust_call_status_arg();
        if needs_call_status {
            let rust_status_ident = ident("u_status_");
            let foreign_status_ident = ident("f_status_");
            let return_ident = ident("value_");
            let ArgumentTokens {
                declaration: let_value,
                returns: return_value,
            } = if_or_default(
                has_return,
                ArgumentTokens {
                    declaration: quote! { let #return_ident = },
                    returns: quote! { #return_ident.into_js() },
                },
            );

            quote! {
                #annotation
                pub fn #foreign_func_ident(#js_args_decl #foreign_status_ident: &mut #runtime::RustCallStatus) #decl_suffix {
                    let mut #rust_status_ident = #uniffi::RustCallStatus::default();
                    #let_value unsafe { #func_ident(#args_into_rust &mut #rust_status_ident) };
                    #foreign_status_ident.copy_from(#rust_status_ident);
                    #return_value
                }
            }
        } else {
            let semicolon = if_or_default(!has_return, quote! { ; });
            quote! {
                #annotation
                pub unsafe fn #foreign_func_ident(#js_args_decl) #decl_suffix {
                    #func_ident(#args_into_rust) #call_suffix #semicolon
                }
            }
        }
    }

    fn ffi_function_literal(&mut self, cb: &FfiCallbackFunction2) -> TokenStream {
        let args = cb.callback().arguments();
        let js_args_decl = self.arg_list_decl(&args, |t| self.ffi_type_foreign_to_rust(t));
        // callback_data: js::UInt64,
        // result: foreign_future_struct_i32::VTableJs,
        let args_into_rust: TokenStream =
            self.arg_list_convert(&args, |ident, type_| self.convert_to_rust(ident, type_));
        // u64::into_rust(callback_data),
        // foreign_future_struct_i32::VTableRs::into_rust(result),
        let rust_args_decl: TokenStream = self.arg_list_decl(&args, |t| self.ffi_type_rust(t));
        // callback_data: u64,
        // result: foreign_future_struct_i32::VTableRs

        let module_ident = cb.module_ident();
        let js_class = cb.js_module_ident();
        let callback_fn_ident = callback_fn_ident(&module_ident);

        quote! {
            mod #module_ident {
                use super::*;

                #[wasm_bindgen(js_name = #js_class)]
                pub struct #callback_fn_ident {
                    callback: FnSig,
                }

                impl #callback_fn_ident {
                    fn new(callback: FnSig) -> Self {
                        Self { callback }
                    }
                }

                #[wasm_bindgen(js_class = #js_class)]
                impl #callback_fn_ident {
                    #[wasm_bindgen]
                    pub fn call(&self,
                        _ctx: &Self,
                        #js_args_decl
                    ) {
                        (self.callback)(#args_into_rust)
                    }
                }

                pub(super) type FnSig = extern "C" fn(
                    #rust_args_decl
                );

                impl IntoJs<#callback_fn_ident> for FnSig {
                    fn into_js(self) -> #callback_fn_ident {
                        #callback_fn_ident::new(self)
                    }
                }
            }
        }
    }

    fn ffi_callback(&mut self, cb: &FfiCallbackFunction2) -> TokenStream {
        let uniffi_ident = self.uniffi_ident();
        let cb_module_ident = cb.module_ident();
        let callback_fn_ident = callback_fn_ident(&cb_module_ident);

        let js_method_decl = self.js_callback_method_decl(&callback_fn_ident, cb.callback());

        let result_ident = ident("uniffi_result_");
        let return_type = if_then_map(cb.has_return_out_param(), || {
            let rt = cb.return_type();
            let rs_ret_name = if rt.is_some() {
                "rs_return_"
            } else {
                "_rs_return"
            };
            let rs_ret_ident = ident(rs_ret_name);

            let rs_return_type = self.ffi_type_rust_out_param(rt.as_ref());
            let declaration = quote! {
                #rs_ret_ident: &mut #rs_return_type,
            };

            let returns = map_or_default(rt.as_ref(), |_| {
                quote! {
                    #result_ident.copy_into_return(#rs_ret_ident);
                }
            });

            ArgumentTokens {
                declaration,
                returns,
            }
        });

        let call_status = if_then_map(cb.callback().has_rust_call_status_arg(), || {
            let rs_call_status = ident("rs_call_status_");
            ArgumentTokens {
                declaration: quote! {
                    #rs_call_status: &mut #uniffi_ident::RustCallStatus,
                },
                returns: quote! {
                    #result_ident.copy_into_status(#rs_call_status);
                },
            }
        });

        let args: Vec<_> = cb.callback().arguments_no_return().collect();
        let rust_args_decl: TokenStream = self.arg_list_decl(&args, |t| self.ffi_type_rust(t));

        let args_into_js: TokenStream =
            self.arg_list_convert(&args, |ident, _| self.convert_to_js(ident));

        // Direct return: e.g., CallbackInterfaceClone: extern "C" fn(handle: u64) -> u64
        // (no out-param, no call-status, but has a Rust-side return type)
        let direct_return: Option<FfiType> = cb
            .callback()
            .return_type()
            .cloned()
            .filter(|_| !cb.has_return_out_param());
        let fn_return_suffix = map_or_default(direct_return.as_ref(), |rt| {
            let rust_return = self.ffi_type_rust(rt);
            quote! { -> #rust_return }
        });
        let direct_return_expr = map_or_default(direct_return.as_ref(), |rt| {
            let rust_return = self.ffi_type_rust(rt);
            quote! { #rust_return::into_rust(#result_ident) }
        });

        let return_let = if_or_default(
            cb.callback().has_rust_call_status_arg()
                || cb.return_type().is_some()
                || direct_return.is_some(),
            quote! {
                let #result_ident =
            },
        );

        let ArgumentTokens {
            declaration: call_status_arg_decl,
            returns: call_status_copy,
        } = call_status;

        let ArgumentTokens {
            declaration: return_arg_decl,
            returns: return_copy,
        } = return_type;

        let runtime_ident = self.runtime_ident();

        let cell = ident("cell_");
        let callback = ident("callback_");

        let inner = quote! {
            use super::*;

            #[wasm_bindgen]
            extern "C" {
                #[wasm_bindgen]
                pub type #callback_fn_ident;

                #js_method_decl
            }

            thread_local! {
                static CALLBACK: #runtime_ident::ForeignCell<#callback_fn_ident> = #runtime_ident::ForeignCell::new();
            }

            impl IntoRust<#callback_fn_ident> for FnSig {
                fn into_rust(callback: #callback_fn_ident) -> Self {
                    CALLBACK.with(|cell| cell.set(callback));
                    implementation
                }
            }

            pub(super) type FnSig = extern "C" fn(#rust_args_decl #return_arg_decl #call_status_arg_decl) #fn_return_suffix;

            extern "C" fn implementation(#rust_args_decl #return_arg_decl #call_status_arg_decl) #fn_return_suffix {
                #return_let CALLBACK.with(|#cell| #cell.with_value(|#callback| #callback.call(#callback, #args_into_js)));
                #call_status_copy
                #return_copy
                #direct_return_expr
            }
        };

        let cb_ident = cb.module_ident();
        let non_snake_case = if_or_default(
            cb.callback().is_free_callback() || cb.callback().is_clone_callback(),
            quote! {
                #[allow(non_snake_case)]
            },
        );
        let tokens = quote! {
            #non_snake_case
            mod #cb_ident {
                #inner
            }
        };
        formatted(tokens.clone(), true).expect("Failed to generate valid rust for ffi_callback");
        tokens
    }

    fn ffi_struct(&self, st: &FfiStruct2) -> TokenStream {
        let module_name = st.module_ident();
        let vtable_rs_fields = st
            .fields()
            .map(|f| {
                let field_name = f.name();
                let field_type = if st.is_callback_method(field_name) {
                    let alias_ident = st.method_alias_ident(field_name);
                    quote! { #alias_ident::FnSig }
                } else {
                    self.ffi_type_rust(&f.type_())
                };
                let field_name = ident(field_name);
                quote! { #field_name: #field_type, }
            })
            .collect::<TokenStream>();

        // These are methods and properties in the JS "type", annotated with
        // wasm_bindgen(method) and wasm_bindgen(getter) macros.
        let vtable_js_fields = st
            .fields()
            .map(|field| {
                let field_name = field.name();
                let field_ident = ident(field_name);
                if st.is_callback_method(field_name) {
                    let alias_ident = st.method_alias_ident(field_name);
                    let mod_ident = st.method_mod_ident(field_name);
                    let callback_fn_ident = callback_fn_ident(&mod_ident);
                    quote! {
                        #[wasm_bindgen(method, getter)]
                        fn #field_ident(this: &VTableJs) -> #alias_ident::#callback_fn_ident;
                    }
                } else {
                    let field_type = field.type_();
                    let type_ = self.ffi_type_foreign_future(&field_type);
                    quote! {
                        #[wasm_bindgen(method, getter)]
                        fn #field_ident(this: &VTableJs) -> #type_;
                    }
                }
            })
            .collect::<TokenStream>();

        let into_rust_block = {
            let from_ident = ident("v_");
            let from_fields = st
                .fields()
                .map(|field| {
                    let field_name = field.name();
                    let field_ident = ident(field_name);
                    if st.is_callback_method(field_name) {
                        let alias_ident = st.method_alias_ident(field_name);
                        quote! {
                            #field_ident: #alias_ident::FnSig::into_rust(#from_ident.#field_ident()),
                        }
                    } else {
                        let rust_type = self.ffi_type_rust(&field.type_());
                        quote! {
                            #field_ident: #rust_type::into_rust(#from_ident.#field_ident()),
                        }
                    }
                })
                .collect::<TokenStream>();
            quote! {
                impl IntoRust<VTableJs> for VTableRs {
                    fn into_rust(#from_ident: VTableJs) -> Self {
                        Self {
                            #from_fields
                        }
                    }
                }
            }
        };

        let copy_into_block = if_then_map(st.is_passed_from_js_to_rust(), || {
            quote! {
                impl VTableJs {
                    #[allow(unused)]
                    pub(super) fn copy_into_return(self, rust: &mut VTableRs) {
                        *rust = <VTableRs>::into_rust(self);
                    }
                }
            }
        });

        let use_statements: TokenStream = st
            .method_names()
            .map(|name| {
                let mod_ident = st.method_mod_ident(name);
                let alias_ident = st.method_alias_ident(name);
                quote! {
                    use super::#mod_ident as #alias_ident;
                }
            })
            .collect();

        quote! {
            mod #module_name {
                use super::*;
                #use_statements

                #[wasm_bindgen]
                extern "C" {
                    pub type VTableJs;

                    #vtable_js_fields
                }

                #[repr(C)]
                pub(super) struct VTableRs {
                    #vtable_rs_fields
                }

                #into_rust_block
                #copy_into_block
            }
        }
    }

    fn js_callback_method_decl(
        &self,
        callback_fn_ident: &Ident,
        ffi_func: &FfiCallbackFunction,
    ) -> TokenStream {
        let args_no_return: Vec<_> = ffi_func.arguments_no_return().collect();
        let args = self.arg_list_decl(&args_no_return, |t| self.ffi_type_foreign(t));
        let is_direct_return = ffi_func.return_type().is_some() && !ffi_func.has_return_out_param();
        let return_tokens = if is_direct_return {
            let rt = ffi_func.return_type().unwrap();
            let return_type = self.ffi_type_foreign(rt);
            quote! { -> #return_type }
        } else if ffi_func.returns_result() {
            let return_type = self.ffi_type_uniffi_result(ffi_func.arg_return_type().as_ref());
            quote! { -> #return_type }
        } else {
            quote! {}
        };
        quote! {
            #[wasm_bindgen(method)]
            pub fn call(this_: &#callback_fn_ident, ctx_: &#callback_fn_ident, #args) #return_tokens;
        }
    }

    fn arg_list_decl<F>(&self, args: &[&FfiArgument], func: F) -> TokenStream
    where
        F: Fn(&FfiType) -> TokenStream,
    {
        args.iter().map(|arg| self.arg_decl(arg, &func)).collect()
    }

    fn arg_list_convert<F>(&self, args: &[&FfiArgument], func: F) -> TokenStream
    where
        F: Fn(Ident, &FfiType) -> TokenStream,
    {
        args.iter()
            .map(|arg| func(ident(arg.name()), &arg.type_()))
            .collect()
    }

    fn arg_decl<F>(&self, arg: &FfiArgument, func: F) -> TokenStream
    where
        F: Fn(&FfiType) -> TokenStream,
    {
        let ident = self.arg_ident(arg);
        let typ = func(&arg.type_());
        quote! { #ident: #typ, }
    }

    fn convert_to_rust(&self, ident: Ident, type_: &FfiType) -> TokenStream {
        let rust_type = self.ffi_type_rust(type_);
        quote! { #rust_type::into_rust(#ident), }
    }

    fn convert_to_js(&self, ident: Ident) -> TokenStream {
        quote! { #ident.into_js(), }
    }

    fn arg_ident(&self, arg: &FfiArgument) -> Ident {
        ident(arg.name())
    }

    fn ffi_type_foreign_to_rust(&self, t: &FfiType) -> TokenStream {
        match t {
            FfiType::Reference(t) => self.ffi_type_foreign(t),
            _ => self.ffi_type_foreign(t),
        }
    }

    fn ffi_type_uniffi_result(&self, t: Option<&FfiType>) -> TokenStream {
        let runtime_ident = self.runtime_ident();
        match t {
            None => quote! { #runtime_ident::UniffiResultVoid },
            Some(t) => match t {
                FfiType::UInt8 => quote! { #runtime_ident::UniffiResultUInt8 },
                FfiType::UInt16 => quote! { #runtime_ident::UniffiResultUInt16 },
                FfiType::UInt32 => quote! { #runtime_ident::UniffiResultUInt32 },
                FfiType::UInt64 => quote! { #runtime_ident::UniffiResultUInt64 },
                FfiType::Int8 => quote! { #runtime_ident::UniffiResultInt8 },
                FfiType::Int16 => quote! { #runtime_ident::UniffiResultInt16 },
                FfiType::Int32 => quote! { #runtime_ident::UniffiResultInt32 },
                FfiType::Int64 => quote! { #runtime_ident::UniffiResultInt64 },
                FfiType::Float32 => quote! { #runtime_ident::UniffiResultFloat32 },
                FfiType::Float64 => quote! { #runtime_ident::UniffiResultFloat64 },
                FfiType::Handle => quote! { #runtime_ident::UniffiResultUInt64 },
                FfiType::RustBuffer(_) | FfiType::ForeignBytes => {
                    quote! { #runtime_ident::UniffiResultForeignBytes }
                }
                FfiType::VoidPointer => quote! { #runtime_ident::UniffiResultVoid },
                FfiType::Struct(s) => {
                    let module_ident = snake_case_ident(s);
                    quote! { #module_ident::VTableJs }
                }
                FfiType::Reference(t) | FfiType::MutReference(t) => {
                    self.ffi_type_uniffi_result(Some(t))
                }
                _ => unreachable!("Uniffi doesn't support returning {t:?} from callbacks"),
            },
        }
    }

    fn ffi_type_foreign_future(&self, t: &FfiType) -> TokenStream {
        match t {
            FfiType::Reference(t) => self.ffi_type_foreign(t),
            _ => self.ffi_type_foreign(t),
        }
    }

    fn ffi_type_foreign(&self, t: &FfiType) -> TokenStream {
        let runtime = self.runtime_ident();
        match t {
            FfiType::UInt8 => quote! { #runtime::UInt8 },
            FfiType::Int8 => quote! { #runtime::Int8 },
            FfiType::UInt16 => quote! { #runtime::UInt16 },
            FfiType::Int16 => quote! { #runtime::Int16 },
            FfiType::UInt32 => quote! { #runtime::UInt32 },
            FfiType::Int32 => quote! { #runtime::Int32 },
            FfiType::UInt64 => quote! { #runtime::UInt64 },
            FfiType::Int64 => quote! { #runtime::Int64 },
            FfiType::Float32 => quote! { #runtime::Float32 },
            FfiType::Float64 => quote! { #runtime::Float64 },
            FfiType::Handle => quote! { #runtime::Handle },
            FfiType::ForeignBytes => quote! { #runtime::ForeignBytes },
            FfiType::RustBuffer(_) => quote! { #runtime::ForeignBytes },
            FfiType::RustCallStatus => quote! { #runtime::RustCallStatus },
            FfiType::VoidPointer => quote! { #runtime::VoidPointer },
            FfiType::Struct(s) => {
                let mod_ident = snake_case_ident(s);
                quote! { #mod_ident::VTableJs }
            }
            FfiType::Callback(cb) => {
                let mod_ident = snake_case_ident(cb);
                let callback_fn_ident = callback_fn_ident(&mod_ident);
                quote! { #mod_ident::#callback_fn_ident }
            }
            FfiType::Reference(_) | FfiType::MutReference(_) => {
                unreachable!("FfiType::Reference should be unpacked by a wrapper function");
            }
        }
    }

    fn ffi_type_rust_out_param(&self, t: Option<&FfiType>) -> TokenStream {
        match t {
            Some(FfiType::Reference(t)) | Some(FfiType::MutReference(t)) => self.ffi_type_rust(t),
            Some(t) => self.ffi_type_rust(t),
            None => quote! { () },
        }
    }

    fn ffi_type_rust(&self, t: &FfiType) -> TokenStream {
        let uniffi = self.uniffi_ident();
        match t {
            FfiType::UInt8 => quote! { u8 },
            FfiType::Int8 => quote! { i8 },
            FfiType::UInt16 => quote! { u16 },
            FfiType::Int16 => quote! { i16 },
            FfiType::UInt32 => quote! { u32 },
            FfiType::Int32 => quote! { i32 },
            FfiType::UInt64 => quote! { u64 },
            FfiType::Int64 => quote! { i64 },
            FfiType::Float32 => quote! { f32 },
            FfiType::Float64 => quote! { f64 },
            FfiType::Handle => quote! { u64 },
            FfiType::ForeignBytes => quote! { #uniffi::RustBuffer },
            FfiType::RustBuffer(_) => quote! { #uniffi::RustBuffer },
            FfiType::RustCallStatus => quote! { #uniffi::RustCallStatus },
            FfiType::VoidPointer => quote! { #uniffi::VoidPointer },
            FfiType::Struct(s) => {
                let mod_ident = snake_case_ident(s);
                quote! { #mod_ident::VTableRs }
            }
            FfiType::Callback(cb) => {
                let mod_ident = snake_case_ident(cb);
                quote! { #mod_ident::FnSig }
            }
            FfiType::Reference(t) | FfiType::MutReference(t) => {
                let typ = self.ffi_type_rust(t);
                quote! { std::ptr::NonNull::<#typ> }
            }
        }
    }
}

#[derive(Default)]
struct ArgumentTokens {
    declaration: TokenStream,
    returns: TokenStream,
}

#[cfg(test)]
mod unit_tests {
    use uniffi_bindgen::interface::{FfiArgument, FfiFunction, FfiType};

    use super::*;

    fn subject<'component>() -> ComponentTemplate<'component> {
        ComponentTemplate::new(
            &Config {},
            &SwitchArgs {
                flavor: crate::AbiFlavor::Wasm,
            },
        )
    }

    fn arg(name: &str, type_: FfiType) -> FfiArgument {
        FfiArgument::new(name, type_)
    }

    fn no_args() -> impl Iterator<Item = FfiArgument> {
        let args = Vec::new();
        args.into_iter()
    }

    fn void() -> Option<FfiType> {
        None
    }

    fn return_(type_: FfiType) -> Option<FfiType> {
        Some(type_)
    }

    fn func(
        nm: &str,
        args: impl Iterator<Item = FfiArgument>,
        return_: Option<FfiType>,
    ) -> FfiFunction {
        let mut func = FfiFunction::default();
        func.init(return_, args);
        func.rename(nm.to_owned());
        func
    }

    fn trim_indent(input: &str) -> String {
        let lines: Vec<&str> = input.lines().collect();
        let non_empty_lines: Vec<&str> = lines
            .iter()
            .skip_while(|&&line| line.trim().is_empty())
            .cloned()
            .collect::<Vec<&str>>()
            .into_iter()
            .rev()
            .skip_while(|line| line.trim().is_empty())
            .collect::<Vec<&str>>()
            .into_iter()
            .rev()
            .collect();

        let min_indent = non_empty_lines
            .iter()
            .filter(|line| !line.trim().is_empty())
            .map(|line| line.chars().take_while(|c| c.is_whitespace()).count())
            .min()
            .unwrap_or(0);

        non_empty_lines
            .iter()
            .map(|line| {
                if line.trim().is_empty() {
                    line.to_string()
                } else {
                    line.chars().skip(min_indent).collect()
                }
            })
            .collect::<Vec<String>>()
            .join("\n")
    }

    #[test]
    fn happy_path() -> Result<()> {
        let mut subject = subject();
        let input = func("happy_path_func", no_args(), return_(FfiType::Int8));
        let output = subject.ffi_function(&input);
        let string = formatted(output, true)?;

        assert_eq!(
            string.trim(),
            trim_indent(
                "
            #[wasm_bindgen]
            pub fn ubrn_happy_path_func(f_status_: &mut js::RustCallStatus) -> js::Int8 {
                let mut u_status_ = u::RustCallStatus::default();
                let value_ = unsafe { happy_path_func(&mut u_status_) };
                f_status_.copy_from(u_status_);
                value_.into_js()
            }"
            )
        );

        let output = subject.ffi_function_decl_c_abi(&input);
        let string = formatted(output, false)?;
        assert_eq!(
            string.trim(),
            "fn happy_path_func (status_ : & mut u :: RustCallStatus) -> i8 ;"
        );
        Ok(())
    }

    #[test]
    fn one_arg() -> Result<()> {
        let mut subject = subject();

        let input = func(
            "one_arg_func",
            vec![arg("num", FfiType::Int32)].into_iter(),
            return_(FfiType::Int8),
        );
        let output = subject.ffi_function(&input);
        let string = formatted(output, true)?;
        assert_eq!(
            string.trim(),
            trim_indent(
                "
            #[wasm_bindgen]
            pub fn ubrn_one_arg_func(
                num: js::Int32,
                f_status_: &mut js::RustCallStatus,
            ) -> js::Int8 {
                let mut u_status_ = u::RustCallStatus::default();
                let value_ = unsafe { one_arg_func(i32::into_rust(num), &mut u_status_) };
                f_status_.copy_from(u_status_);
                value_.into_js()
            }"
            )
        );

        let output = subject.ffi_function_decl_c_abi(&input);
        let string = formatted(output, false)?;
        assert_eq!(
            string.trim(),
            "fn one_arg_func (num : i32 , status_ : & mut u :: RustCallStatus) -> i8 ;"
        );
        Ok(())
    }

    #[test]
    fn two_args() -> Result<()> {
        let mut subject = subject();

        let input = func(
            "two_arg_func",
            vec![arg("left", FfiType::Int32), arg("right", FfiType::Float32)].into_iter(),
            return_(FfiType::Int8),
        );
        let output = subject.ffi_function(&input);
        let string = formatted(output, true)?;
        assert_eq!(
            string.trim(),
            trim_indent(
                "
                #[wasm_bindgen]
                pub fn ubrn_two_arg_func(
                    left: js::Int32,
                    right: js::Float32,
                    f_status_: &mut js::RustCallStatus,
                ) -> js::Int8 {
                    let mut u_status_ = u::RustCallStatus::default();
                    let value_ = unsafe {
                        two_arg_func(i32::into_rust(left), f32::into_rust(right), &mut u_status_)
                    };
                    f_status_.copy_from(u_status_);
                    value_.into_js()
                }"
            )
        );

        let output = subject.ffi_function_decl_c_abi(&input);
        let string = formatted(output, false)?;
        assert_eq!(string.trim(), "fn two_arg_func (left : i32 , right : f32 , status_ : & mut u :: RustCallStatus) -> i8 ;");
        Ok(())
    }

    #[test]
    fn void_return() -> Result<()> {
        let mut subject = subject();

        let input = func("void_return_func", no_args(), void());
        let output = subject.ffi_function(&input);
        let string = formatted(output, true)?;
        assert_eq!(
            string.trim(),
            trim_indent(
                "
                #[wasm_bindgen]
                pub fn ubrn_void_return_func(f_status_: &mut js::RustCallStatus) {
                    let mut u_status_ = u::RustCallStatus::default();
                    unsafe { void_return_func(&mut u_status_) };
                    f_status_.copy_from(u_status_);
                }"
            )
        );

        let output = subject.ffi_function_decl_c_abi(&input);
        let string = formatted(output, false)?;
        assert_eq!(
            string.trim(),
            "fn void_return_func (status_ : & mut u :: RustCallStatus) ;"
        );
        Ok(())
    }
}
