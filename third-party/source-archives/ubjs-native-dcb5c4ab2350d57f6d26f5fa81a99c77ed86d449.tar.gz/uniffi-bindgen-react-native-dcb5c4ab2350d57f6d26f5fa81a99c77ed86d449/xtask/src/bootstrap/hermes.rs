/*
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/
 */
use std::process::Command;

use anyhow::Result;
use camino::Utf8PathBuf;
use clap::Args;
use ubrn_common::{rm_dir, run_cmd};

use crate::util::{build_root, cpp_modules};

use super::Bootstrap;

#[derive(Debug, Args)]
pub(crate) struct HermesCmd {
    /// Fetch the hermes from this repo
    #[clap(long, default_value = "facebook/hermes")]
    repo: String,

    /// Fetch this branch from the hermes repo
    #[clap(long, short = 'b', default_value = "main")]
    branch: String,
}

impl Default for HermesCmd {
    fn default() -> Self {
        Self {
            repo: "facebook/hermes".to_owned(),
            branch: "main".to_owned(),
        }
    }
}

impl HermesCmd {
    pub fn src_dir() -> Result<Utf8PathBuf> {
        let root = cpp_modules()?;
        Ok(root.join("hermes"))
    }

    pub fn build_dir() -> Result<Utf8PathBuf> {
        let root = build_root()?;
        Ok(root.join("hermes"))
    }

    fn checkout(&self) -> Result<()> {
        let dir = Self::src_dir()?;
        if dir.exists() {
            return Ok(());
        }
        let parent = dir.parent().expect("Hermes directory has no parent");

        ubrn_common::mk_dir(parent)?;
        let repo = format!("https://github.com/{}.git", self.repo);

        run_cmd(
            Command::new("git")
                .arg("clone")
                .arg("--single-branch")
                .arg("-b")
                .arg(self.branch.as_str())
                .arg(&repo)
                .arg(&dir),
        )?;

        Ok(())
    }
}

impl Bootstrap for HermesCmd {
    fn marker() -> Result<Utf8PathBuf> {
        Self::build_dir()
    }

    fn clean() -> Result<()> {
        rm_dir(Self::build_dir()?)?;
        rm_dir(Self::src_dir()?)?;
        Ok(())
    }

    fn prepare(&self) -> Result<()> {
        self.checkout()?;
        let src = Self::src_dir()?;
        let dir = Self::build_dir()?;

        ubrn_common::mk_dir(&dir)?;

        let mut cmd = Command::new("cmake");
        cmd.current_dir(&dir)
            .arg("-G")
            .arg(if cfg!(target_os = "windows") {
                "Visual Studio 16 2019"
            } else {
                "Ninja"
            })
            .arg("-DHERMES_BUILD_APPLE_FRAMEWORK=OFF")
            .arg("-DCMAKE_BUILD_TYPE=Release");
        if cfg!(target_os = "windows") {
            // The VS generator defaults to static libs, which would require
            // consumers to link the entire Hermes transitive dependency chain.
            // Shared libs avoid this by resolving their own dependencies.
            cmd.arg("-DBUILD_SHARED_LIBS=ON");
        }
        run_cmd(cmd.arg(&src))?;

        if cfg!(target_os = "windows") {
            let mut cmd = Command::new("cmake");
            run_cmd(cmd.current_dir(&dir).arg("--build").arg(&dir))?;
        } else {
            let mut cmd = Command::new("ninja");
            run_cmd(cmd.current_dir(&dir))?;
        }
        Ok(())
    }
}
