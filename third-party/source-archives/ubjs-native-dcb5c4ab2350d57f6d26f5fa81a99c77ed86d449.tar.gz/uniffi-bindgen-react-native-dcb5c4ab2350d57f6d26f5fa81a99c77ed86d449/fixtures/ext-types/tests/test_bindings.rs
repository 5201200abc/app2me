/*
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/
 */
ubrn_macros::build_foreign_language_testcases! {
    "tests/bindings/test_ext_types.ts" => [Jsi, Wasm, Napi],
    "tests/bindings/test_ext_types_with_index.ts" => [Napi],
}
