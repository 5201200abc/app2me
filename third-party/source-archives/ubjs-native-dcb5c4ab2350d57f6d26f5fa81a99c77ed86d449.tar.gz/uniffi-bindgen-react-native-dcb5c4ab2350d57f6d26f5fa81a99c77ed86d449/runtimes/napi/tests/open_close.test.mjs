/*
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/
 */
import { test } from "node:test";
import assert from "node:assert";
import lib from "../lib.js";
const { UniffiNativeModule } = lib;
import { libPath } from "./helpers/lib-path.mjs";

const LIB_PATH = libPath("uniffi_napi_test_lib");

const SYMBOLS = {
  rustbuffer_alloc: "uniffi_test_rustbuffer_alloc",
  rustbuffer_free: "uniffi_test_rustbuffer_free",
  rustbuffer_from_bytes: "uniffi_test_rustbuffer_from_bytes",
};

test("open() loads a library", () => {
  const lib = UniffiNativeModule.open(LIB_PATH);
  assert.ok(lib);
});

test("open() throws for nonexistent library", () => {
  assert.throws(() => {
    UniffiNativeModule.open("/nonexistent/lib.dylib");
  }, /Error/);
});

test("register() throws for missing symbol", () => {
  const lib = UniffiNativeModule.open(LIB_PATH);
  assert.throws(() => {
    lib.register({
      symbols: {
        rustbuffer_alloc: "nonexistent_symbol",
        rustbuffer_free: "uniffi_test_rustbuffer_free",
        rustbuffer_from_bytes: "uniffi_test_rustbuffer_from_bytes",
      },
      structs: {},
      callbacks: {},
      functions: {},
    });
  }, /Error/);
});
